@echo off
echo === DESCARGANDO DRIVER DE MARIADB ===
echo.

REM URL del JAR de MariaDB
set JAR_URL=https://repo1.maven.org/maven2/org/mariadb/jdbc/mariadb-java-client/3.3.2/mariadb-java-client-3.3.2.jar

REM Descargar usando PowerShell
echo Descargando mariadb-java-client-3.3.2.jar...
powershell -Command "Invoke-WebRequest -Uri '%JAR_URL%' -OutFile 'lib\mariadb-java-client-3.3.2.jar'"

if exist "lib\mariadb-java-client-3.3.2.jar" (
    echo ✓ JAR descargado exitosamente
    echo Tamaño del archivo:
    dir "lib\mariadb-java-client-3.3.2.jar"
) else (
    echo ✗ Error al descargar el JAR
    echo.
    echo ALTERNATIVA: Descarga manual desde:
    echo https://repo1.maven.org/maven2/org/mariadb/jdbc/mariadb-java-client/3.3.2/mariadb-java-client-3.3.2.jar
    echo.
    echo Y colócalo en: lib\mariadb-java-client-3.3.2.jar
)

echo.
pause
