@echo off
echo === COMPILANDO Y EJECUTANDO DIAGNÓSTICO DE BD ===
echo.

REM Cambiar al directorio del proyecto
cd /d "c:\Users\1097514221\OneDrive\Documentos\POO\Proyecto 3\POO"

REM Crear directorio de clases si no existe
if not exist "classes" mkdir classes

REM Compilar con el JAR de MariaDB en el classpath
echo Compilando...
javac -cp "lib\mariadb-java-client-3.3.2.jar;." -d classes src\Test\DiagnosticoDB.java

if errorlevel 1 (
    echo.
    echo *** ERROR DE COMPILACIÓN ***
    pause
    exit /b 1
)

echo ✓ Compilación exitosa
echo.
echo Ejecutando diagnóstico...
echo.

REM Ejecutar con el JAR en el classpath
java -cp "classes;lib\mariadb-java-client-3.3.2.jar" Test.DiagnosticoDB

echo.
echo === DIAGNÓSTICO COMPLETADO ===
pause
