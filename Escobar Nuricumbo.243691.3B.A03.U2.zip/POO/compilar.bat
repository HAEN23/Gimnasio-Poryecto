@echo off
echo === COMPILANDO PROYECTO GYM ===
echo.

REM Cambiar al directorio del proyecto
cd /d "c:\Users\1097514221\OneDrive\Documentos\POO\Proyecto 3\POO"

REM Crear directorio de clases si no existe
if not exist "classes" mkdir classes

REM Verificar que el JAR de MariaDB existe
if not exist "lib\mariadb-java-client-3.3.2.jar" (
    echo ✗ JAR de MariaDB no encontrado
    echo Ejecuta: descargar_driver.bat
    pause
    exit /b 1
)

REM Compilar todos los archivos Java
echo Compilando archivos Java...
javac -cp "lib\mariadb-java-client-3.3.2.jar" -d classes src\**\*.java

if errorlevel 1 (
    echo.
    echo *** ERROR DE COMPILACIÓN ***
    pause
    exit /b 1
)

echo ✓ Compilación exitosa
echo.

REM Encontrar y ejecutar la clase principal
echo Buscando clase principal...
for /r classes %%f in (*.class) do (
    echo Encontrado: %%f
)

echo.
echo Para ejecutar la aplicación, usa:
echo java -cp "classes;lib\mariadb-java-client-3.3.2.jar" [NombreClasePrincipal]
echo.
echo Por ejemplo, si hay un Main.java:
echo java -cp "classes;lib\mariadb-java-client-3.3.2.jar" Main
echo.

pause
