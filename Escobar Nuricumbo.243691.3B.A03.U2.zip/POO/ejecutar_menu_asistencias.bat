@echo off
echo Ejecutando Menu de Asistencias...
java -cp "lib\mariadb-java-client-3.3.2.jar;bin" Menus.MenuAsistencias
pause
