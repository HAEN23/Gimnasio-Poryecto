@echo off
echo Ejecutando Menu de Usuarios...
java -cp "lib\mariadb-java-client-3.3.2.jar;bin" Menus.MenuUsuarios
pause
