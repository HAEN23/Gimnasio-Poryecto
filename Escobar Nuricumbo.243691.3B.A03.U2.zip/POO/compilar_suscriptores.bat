@echo off
echo === COMPILANDO PROYECTO GYM (Solo archivos necesarios) ===
echo.

REM Cambiar al directorio del proyecto
cd /d "c:\Users\1097514221\OneDrive\Documentos\POO\Proyecto 3\POO"

REM Crear directorio de clases si no existe
if not exist "classes" mkdir classes

REM Compilar en orden de dependencias
echo Compilando modelos...
javac -cp "lib\mariadb-java-client-3.3.2.jar" -d classes src\modelos\*.java

echo Compilando utilidades...
javac -cp "lib\mariadb-java-client-3.3.2.jar" -d classes src\util\*.java

echo Compilando repositorios...
javac -cp "lib\mariadb-java-client-3.3.2.jar;classes" -d classes src\Repositorios\SuscriptorRepoMemoria.java
javac -cp "lib\mariadb-java-client-3.3.2.jar;classes" -d classes src\Repositorios\UsuarioRepository.java
javac -cp "lib\mariadb-java-client-3.3.2.jar;classes" -d classes src\Repositorios\RepositorioManager.java

echo Compilando menú de suscriptores...
javac -cp "lib\mariadb-java-client-3.3.2.jar;classes" -d classes src\Menus\MenuSuscriptores.java

echo.
echo ✓ Compilación completada
echo.

echo Para probar el menú de suscriptores:
echo java -cp "classes;lib\mariadb-java-client-3.3.2.jar" Menus.MenuSuscriptores
echo.

pause
