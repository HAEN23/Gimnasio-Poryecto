@echo off
echo ===============================================
echo    SISTEMA DE GIMNASIO - MENU PRINCIPAL
echo ===============================================
echo.
echo Iniciando aplicacion...
java -cp "lib\mariadb-java-client-3.3.2.jar;bin" Menus.MainMenu
echo.
echo Aplicacion terminada.
pause
