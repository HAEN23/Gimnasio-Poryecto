@echo off
echo === COMPILANDO PROYECTO COMPLETO ===
echo.

REM Cambiar al directorio del proyecto
cd /d "c:\Users\1097514221\OneDrive\Documentos\POO\Proyecto 3\POO"

REM Limpiar clases anteriores
if exist "classes" (
    echo Limpiando clases anteriores...
    rmdir /s /q classes
)
mkdir classes

echo Compilando en orden de dependencias...

REM 1. Compilar modelos
echo [1/6] Compilando modelos...
javac -d classes src\modelos\*.java
if errorlevel 1 goto error

REM 2. Compilar utilidades
echo [2/6] Compilando utilidades...
javac -cp "lib\mariadb-java-client-3.3.2.jar;classes" -d classes src\util\*.java
if errorlevel 1 goto error

REM 3. Compilar repositorios base
echo [3/6] Compilando repositorios base...
javac -cp "lib\mariadb-java-client-3.3.2.jar;classes" -d classes src\Repositorios\Usuariorepo.java
javac -cp "lib\mariadb-java-client-3.3.2.jar;classes" -d classes src\Repositorios\SuscriptorRepo.java
javac -cp "lib\mariadb-java-client-3.3.2.jar;classes" -d classes src\Repositorios\*repo.java
if errorlevel 1 goto error

REM 4. Compilar UsuarioRepositoryDB
echo [4/6] Compilando UsuarioRepositoryDB...
javac -cp "lib\mariadb-java-client-3.3.2.jar;classes" -d classes src\Repositorios\UsuarioRepositoryDB.java
if errorlevel 1 goto error

REM 5. Compilar RepositorioManager
echo [5/6] Compilando RepositorioManager...
javac -cp "lib\mariadb-java-client-3.3.2.jar;classes" -d classes src\Repositorios\RepositorioManager.java
if errorlevel 1 goto error

REM 6. Compilar Menús
echo [6/6] Compilando menús...
javac -cp "lib\mariadb-java-client-3.3.2.jar;classes" -d classes src\Menus\MenuSuscriptoresNuevo.java
if errorlevel 1 goto error

echo.
echo ✓ ¡Compilación exitosa!
echo.
echo Para ejecutar el menú de suscriptores:
echo java -cp "classes;lib\mariadb-java-client-3.3.2.jar" Menus.MenuSuscriptoresNuevo
echo.
goto end

:error
echo.
echo ✗ Error en la compilación
echo.

:end
pause
