@echo off
echo Ejecutando Menu de Pagos...
java -cp "lib\mariadb-java-client-3.3.2.jar;bin" Menus.MenuPagos
pause
