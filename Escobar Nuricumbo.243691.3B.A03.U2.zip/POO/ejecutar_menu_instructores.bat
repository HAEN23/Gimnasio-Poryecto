@echo off
echo Ejecutando Menu de Instructores...
java -cp "lib\mariadb-java-client-3.3.2.jar;bin" Menus.MenuInstructores
pause
