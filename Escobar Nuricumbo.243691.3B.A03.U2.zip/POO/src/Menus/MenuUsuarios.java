package Menus;

import modelos.Usuario;
import Repositorios.UsuarioRepository;
import Repositorios.AdministrarRepo;
import java.util.Scanner;
import java.util.Optional;
import java.util.ArrayList;

public class MenuUsuarios {
    private static UsuarioRepository repositorio = AdministrarRepo.getUsuarioRepository();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            System.out.println("\n=== MENÚ DE USUARIOS ===");
            System.out.println("1. Crear nuevo usuario");
            System.out.println("2. Buscar usuario por ID");
            System.out.println("3. Verificar existencia de usuario");
            System.out.println("4. Eliminar usuario");
            System.out.println("5. Mostrar todos los usuarios");
            System.out.println("6. Salir");
            System.out.print("Seleccione una opción: ");

            int opcion = scanner.nextInt();
            scanner.nextLine(); // Limpiar buffer

            switch (opcion) {
                case 1:
                    crearUsuario();
                    break;
                case 2:
                    buscarUsuario();
                    break;
                case 3:
                    verificarUsuario();
                    break;
                case 4:
                    eliminarUsuario();
                    break;
                case 5:
                    listarUsuarios();
                    break;
                case 6:
                    System.out.println("Regresando al menú principal...");
                    return;
                default:
                    System.out.println("Opción no válida");
            }
        }
    }

    private static void crearUsuario() {
        System.out.println("\n--- CREAR USUARIO ---");
        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();

        System.out.print("Apellido: ");
        String apellido = scanner.nextLine();

        System.out.print("Contacto: ");
        String contacto = scanner.nextLine();

        Usuario nuevoUsuario = new Usuario(nombre, apellido, contacto);
        repositorio.save(nuevoUsuario);

        System.out.println("Usuario creado con ID: " + nuevoUsuario.getId());
    }

    private static void buscarUsuario() {
        System.out.println("\n--- BUSCAR USUARIO ---");
        System.out.print("Ingrese ID: ");
        int id = scanner.nextInt();

        Optional<Usuario> usuario = repositorio.findById(id);
        if (usuario.isPresent()) {
            System.out.println("Usuario encontrado:");
            System.out.println(usuario.get());
        } else {
            System.out.println("Usuario no encontrado");
        }
    }

    private static void verificarUsuario() {
        System.out.println("\n--- VERIFICAR USUARIO ---");
        System.out.print("Ingrese ID: ");
        int id = scanner.nextInt();

        boolean existe = repositorio.existsById(id);
        System.out.println(existe ? "El usuario existe" : "Usuario no registrado");
    }

    private static void eliminarUsuario() {
        System.out.println("\n--- ELIMINAR USUARIO ---");
        System.out.print("Ingrese ID: ");
        int id = scanner.nextInt();

        if (repositorio.existsById(id)) {
            repositorio.removeById(id);
            System.out.println("Usuario eliminado");
        } else {
            System.out.println("No existe usuario con ese ID");
        }
    }

    private static void listarUsuarios() {
        System.out.println("\n--- LISTA DE USUARIOS ---");
        ArrayList<Usuario> usuarios = repositorio.getAll();

        if (usuarios.isEmpty()) {
            System.out.println("No hay usuarios registrados");
        } else {
            usuarios.forEach(System.out::println);
        }
    }
}
