package Menus;

import java.util.Scanner;

public class MainMenu {
    private static Scanner scanner = new Scanner(System.in);//Lo usaremos para leer la entrada del usuario desde la consola. 
    
    public static void main(String[] args) {
        while (true) {
            System.out.println("\n=== BIENVENIDO AL SISTEMA DE GIMNASIO ===");
            System.out.println("Seleccione una opción:");
            System.out.println("1. Menú de Cursos");
            System.out.println("2. Menú de Usuarios");
            System.out.println("3. Menu de Instructores");
            System.out.println("4. Menú de Suscriptores");
            System.out.println("5. Menú de Asistencias");
            System.out.println("6. Menú de Pagos");
            System.out.println("7. Salir");
            System.out.print("Ingrese su opción: ");

            int opcion = scanner.nextInt();
            scanner.nextLine(); // Limpiar buffer para que no haya datos sobrantes

            switch (opcion) {
                case 1:
                    MenuCursos.main(new String[0]);// estamos llamando al método main de la clase MenuCursos y le estamos pasando un arreglo vacío de cadenas como argumento.
                    break;
                case 2:
                    MenuUsuarios.main(new String[0]);
                    break;
                case 3:
                    MenuInstructores.main(new String[0]);
                    break;
                case 4:
                    MenuSuscriptoresNuevo.main(new String[0]);
                    break;
                case 5:
                    MenuAsistencias.main(new String[0]);
                    break;
                case 6:
                    MenuPagos.main(new String[0]);
                    break;
                case 7:
                    System.out.println("Saliendo del sistema...");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Opción no válida");
            }
        }
    }
}
