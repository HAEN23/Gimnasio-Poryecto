package Menus;

import modelos.Pago;
import Repositorios.PagoRepository;
import Repositorios.AdministrarRepo;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;

public class MenuPagos {
    private static PagoRepository repositorio = AdministrarRepo.getPagoRepo();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            System.out.println("\n=== MENÚ DE PAGOS ===");
            System.out.println("1. Registrar nuevo pago");
            System.out.println("2. Buscar pago por ID");
            System.out.println("3. Buscar pagos por membresía");
            System.out.println("4. Listar todos los pagos");
            System.out.println("5. Procesar pago");
            System.out.println("6. Salir");
            System.out.print("Seleccione una opción: ");

            int opcion = scanner.nextInt();
            scanner.nextLine(); // Limpiar buffer

            switch (opcion) {
                case 1:
                    registrarPago();
                    break;
                case 2:
                    buscarPagoPorId();
                    break;
                case 3:
                    buscarPagosPorMembresia();
                    break;
                case 4:
                    listarTodosLosPagos();
                    break;
                case 5:
                    procesarPago();
                    break;
                case 6:
                    System.out.println("Regresando al menú principal...");
                    return;
                default:
                    System.out.println("Opción no válida");
            }
        }
    }

    private static void registrarPago() {
        System.out.println("\n--- REGISTRAR PAGO ---");
        System.out.print("Monto del pago: ");
        double monto = scanner.nextDouble();
        scanner.nextLine(); // Limpiar buffer

        System.out.print("Número de membresía: ");
        String membresia = scanner.nextLine();

        Pago nuevoPago = new Pago(monto, membresia);
        repositorio.guardar(nuevoPago);

        System.out.println("Pago registrado con ID: " + nuevoPago.getIdPago());
    }

    private static void buscarPagoPorId() {
        System.out.println("\n--- BUSCAR PAGO POR ID ---");
        System.out.print("Ingrese ID de pago: ");
        String idPago = scanner.nextLine();

        Optional<Pago> pago = repositorio.buscarPorId(idPago);
        if (pago.isPresent()) {
            System.out.println(pago.get());
        } else {
            System.out.println("No se encontró pago con ese ID");
        }
    }

    private static void buscarPagosPorMembresia() {
        System.out.println("\n--- BUSCAR PAGOS POR MEMBRESÍA ---");
        System.out.print("Ingrese número de membresía: ");
        String membresia = scanner.nextLine();

        List<Pago> pagos = repositorio.buscarPorMembresia(membresia);
        if (pagos.isEmpty()) {
            System.out.println("No se encontraron pagos para esta membresía");
        } else {
            pagos.forEach(System.out::println);
        }
    }

    private static void listarTodosLosPagos() {
        System.out.println("\n--- LISTADO DE TODOS LOS PAGOS ---");
        List<Pago> todosLosPagos = repositorio.obtenerTodos();
        if (todosLosPagos.isEmpty()) {
            System.out.println("No hay pagos registrados");
        } else {
            todosLosPagos.forEach(System.out::println);
        }
    }

    private static void procesarPago() {
        System.out.println("\n--- PROCESAR PAGO ---");
        System.out.print("Ingrese ID de pago: ");
        String idPago = scanner.nextLine();

        Optional<Pago> pagoOpt = repositorio.buscarPorId(idPago);
        if (pagoOpt.isPresent()) {
            Pago pago = pagoOpt.get();
            if (pago.procesarPagoMembresia()) {
                System.out.println("Pago procesado exitosamente");
                System.out.println(pago);
            } else {
                System.out.println("Error: El monto debe ser mayor a 0");
            }
        } else {
            System.out.println("No se encontró pago con ese ID");
        }
    }
}