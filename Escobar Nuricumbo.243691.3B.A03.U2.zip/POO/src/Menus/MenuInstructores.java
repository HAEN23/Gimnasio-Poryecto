package Menus;

import modelos.Instructor;
import Repositorios.Instructorrepo;
import Repositorios.AdministrarRepo;
import Cursos.Curso;
import Repositorios.CursoRepo;
import java.util.Scanner;
import java.util.Optional;
import java.util.ArrayList;

public class MenuInstructores {
    private static Instructorrepo repositorio = AdministrarRepo.getInstructorRepo();
    private static CursoRepo cursoRepo = AdministrarRepo.getCursoRepo();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            System.out.println("\n=== MENÚ DE INSTRUCTORES ===");
            System.out.println("1. Registrar nuevo instructor");
            System.out.println("2. Buscar instructor");
            System.out.println("3. Listar todos los instructores");
            System.out.println("4. Eliminar instructor");
            System.out.println("5. Asignar instructor a curso");
            System.out.println("6. Salir");
            System.out.print("Seleccione una opción: ");

            int opcion = scanner.nextInt();
            scanner.nextLine(); // Limpiar buffer

            switch (opcion) {
                case 1:
                    registrarInstructor();
                    break;
                case 2:
                    buscarInstructor();
                    break;
                case 3:
                    listarInstructores();
                    break;
                case 4:
                    eliminarInstructor();
                    break;
                case 5:
                    asignarInstructorCurso();
                    break;
                case 6:
                    System.out.println("Regresando al menú principal...");
                    return;
                default:
                    System.out.println("Opción no válida");
            }
        }
    }

    private static void registrarInstructor() {
        System.out.println("\n--- REGISTRAR INSTRUCTOR ---");
        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();

        System.out.print("Apellido: ");
        String apellido = scanner.nextLine();

        System.out.print("Contacto: ");
        String contacto = scanner.nextLine();

        System.out.print("Número de instructor (ej. INST-001): ");
        String numeroInstructor = scanner.nextLine();

        Instructor nuevo = new Instructor(nombre, apellido, contacto, numeroInstructor);
        repositorio.guardar(nuevo);

        System.out.println("Instructor registrado exitosamente!");
        System.out.println("ID asignado: " + nuevo.getId());
    }

    private static void buscarInstructor() {
        System.out.println("\n--- BUSCAR INSTRUCTOR ---");
        System.out.print("Ingrese número de instructor: ");
        String numero = scanner.nextLine();

        Optional<Instructor> resultado = repositorio.buscarPorNumero(numero);
        if (resultado.isPresent()) {
            System.out.println("\nInformación del instructor:");
            System.out.println(resultado.get());
        } else {
            System.out.println("No se encontró instructor con ese número");
        }
    }

    private static void listarInstructores() {
        System.out.println("\n--- LISTA DE INSTRUCTORES ---");
        ArrayList<Instructor> instructores = repositorio.obtenerTodos();

        if (instructores.isEmpty()) {
            System.out.println("No hay instructores registrados");
        } else {
            instructores.forEach(System.out::println);
        }
    }

    private static void eliminarInstructor() {
        System.out.println("\n--- ELIMINAR INSTRUCTOR ---");
        System.out.print("Ingrese número de instructor: ");
        String numero = scanner.nextLine();

        if (repositorio.existe(numero)) {
            repositorio.eliminar(numero);
            System.out.println("Instructor eliminado correctamente");
        } else {
            System.out.println("Error: No existe un instructor con ese número");
        }
    }

    private static void asignarInstructorCurso() {
        System.out.println("\n--- ASIGNAR INSTRUCTOR A CURSO ---");

        // Mostrar cursos disponibles
        System.out.println("Cursos disponibles:");
        ArrayList<Curso> cursos = cursoRepo.obtenerTodos();

        if (cursos.isEmpty()) {
            System.out.println("No hay cursos disponibles");
            return;
        }

        for (Curso curso : cursos) {
            System.out.println("Curso " + curso.getNumero() + ": " + curso.getInformacion() +
                    " - Instructor actual: " + curso.getInfoInstructor());
        }

        System.out.print("\nIngrese número del curso: ");
        int numeroCurso = scanner.nextInt();
        scanner.nextLine();

        Optional<Curso> cursoOpt = cursoRepo.buscar(numeroCurso);
        if (!cursoOpt.isPresent()) {
            System.out.println("Error: Curso no encontrado");
            return;
        }

        // Mostrar instructores disponibles
        System.out.println("\nInstructores disponibles:");
        ArrayList<Instructor> instructores = repositorio.obtenerTodos();

        if (instructores.isEmpty()) {
            System.out.println("No hay instructores disponibles");
            return;
        }

        for (Instructor instructor : instructores) {
            System.out.println("- " + instructor.getNumeroInstructor() + ": " + instructor.getNombre() + " "
                    + instructor.getApellido());
        }

        System.out.print("\nIngrese número del instructor: ");
        String numeroInstructor = scanner.nextLine();

        Optional<Instructor> instructorOpt = repositorio.buscarPorNumero(numeroInstructor);
        if (!instructorOpt.isPresent()) {
            System.out.println("Error: Instructor no encontrado");
            return;
        }

        // Crear un nuevo curso con el instructor asignado
        Curso cursoActual = cursoOpt.get();
        Curso cursoActualizado = new Curso(cursoActual.getNumero(), cursoActual.getPeriodo(),
                cursoActual.getInformacion(), instructorOpt.get());

        // Copiar los suscriptores del curso original
        for (modelos.Suscriptor suscriptor : cursoActual.getSuscriptores()) {
            cursoActualizado.inscribir(suscriptor);
        }

        // Actualizar el curso en el repositorio
        cursoRepo.eliminar(numeroCurso);
        cursoRepo.guardar(cursoActualizado);

        System.out.println("Instructor asignado exitosamente al curso!");
        System.out.println("Curso: " + cursoActualizado.getNumero() + " - " + cursoActualizado.getInformacion());
        System.out.println("Instructor: " + instructorOpt.get().getNombre() + " " + instructorOpt.get().getApellido());
    }
}