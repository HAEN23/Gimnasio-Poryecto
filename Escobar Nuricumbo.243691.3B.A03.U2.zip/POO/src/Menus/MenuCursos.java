package Menus;

import Cursos.Curso;
import Repositorios.CursoRepo;
import Repositorios.AdministrarRepo;
import modelos.Instructor;
import modelos.Suscriptor;
import java.util.Optional;
import java.util.Scanner;

public class MenuCursos {
    private static CursoRepo repositorio = AdministrarRepo.getCursoRepo();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            System.out.println("\n=== MENÚ DE CURSOS ===");
            System.out.println("1. Crear nuevo curso");
            System.out.println("2. Buscar curso");
            System.out.println("3. Inscribir suscriptor");
            System.out.println("4. Registrar asistencia");
            System.out.println("5. Eliminar curso");
            System.out.println("6. Salir");
            System.out.print("Seleccione una opción: ");

            int opcion = scanner.nextInt();
            scanner.nextLine(); // Limpiar buffer

            switch (opcion) {
                case 1:
                    crearCurso();
                    break;
                case 2:
                    buscarCurso();
                    break;
                case 3:
                    inscribirSuscriptor();
                    break;
                case 4:
                    registrarAsistencia();
                    break;
                case 5:
                    eliminarCurso();
                    break;
                case 6:
                    System.out.println("Regresando al menú principal...");
                    return;
                default:
                    System.out.println("Opción no válida");
            }
        }
    }

    private static void crearCurso() {
        System.out.println("\n--- CREAR NUEVO CURSO ---");
        System.out.print("Número del curso: ");
        int numero = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Período: ");
        String periodo = scanner.nextLine();

        System.out.print("Información general: ");
        String informacion = scanner.nextLine();

        System.out.print("¿Tiene instructor? (S/N): ");
        Curso nuevoCurso;
        if (scanner.nextLine().equalsIgnoreCase("S")) {
            System.out.print("Nombre del instructor: ");
            String nombreInstructor = scanner.nextLine();
            System.out.print("Número de instructor: ");
            String numeroInstructor = scanner.nextLine();
            Instructor instructor = new Instructor(nombreInstructor, "", "", numeroInstructor);
            nuevoCurso = new Curso(numero, periodo, informacion, instructor);
        } else {
            nuevoCurso = new Curso(numero, periodo, informacion);
        }

        repositorio.guardar(nuevoCurso);
        System.out.println("Curso creado exitosamente!");
    }

    private static void buscarCurso() {
        System.out.println("\n--- BUSCAR CURSO ---");
        System.out.print("Ingrese número de curso: ");
        int numero = scanner.nextInt();
        scanner.nextLine();

        Optional<Curso> curso = repositorio.buscar(numero);
        if (curso.isPresent()) {
            System.out.println("\nInformación del curso:");
            System.out.println(curso.get());
            System.out.println("Instructor: " + curso.get().getInfoInstructor());
        } else {
            System.out.println("No se encontró el curso");
        }
    }

    private static void inscribirSuscriptor() {
        System.out.println("\n--- INSCRIBIR SUSCRIPTOR ---");
        System.out.print("Número de curso: ");
        int numeroCurso = scanner.nextInt();
        scanner.nextLine();

        Optional<Curso> cursoOpt = repositorio.buscar(numeroCurso);
        if (!cursoOpt.isPresent()) {
            System.out.println("Error: Curso no encontrado");
            return;
        }

        System.out.print("Número de membresía del suscriptor (ej. MEM-001, MEM-2024-001): ");
        String membresia = scanner.nextLine();
        // En un sistema real, buscaríamos el suscriptor en su repositorio
        Suscriptor suscriptor = new Suscriptor("", "", "", membresia, true, "");

        if (cursoOpt.get().inscribir(suscriptor)) {
            System.out.println("Suscriptor inscrito exitosamente");
        } else {
            System.out.println("Error: Suscriptor ya inscrito");
        }
    }

    private static void registrarAsistencia() {
        System.out.println("\n--- REGISTRAR ASISTENCIA ---");
        System.out.print("Número de curso: ");
        int numeroCurso = scanner.nextInt();
        scanner.nextLine();

        Optional<Curso> cursoOpt = repositorio.buscar(numeroCurso);
        if (!cursoOpt.isPresent()) {
            System.out.println("Error: Curso no encontrado");
            return;
        }

        System.out.print("Número de membresía (ej. MEM-001, MEM-2024-001): ");
        String membresia = scanner.nextLine();
        System.out.print("¿Asistió? (S/N): ");
        boolean presente = scanner.nextLine().equalsIgnoreCase("S");

        cursoOpt.get().registrarAsistencia(membresia, presente);
        System.out.println("Asistencia registrada");
    }

    private static void eliminarCurso() {
        System.out.println("\n--- ELIMINAR CURSO ---");
        System.out.print("Número de curso: ");
        int numero = scanner.nextInt();
        scanner.nextLine();

        if (repositorio.existe(numero)) {
            repositorio.eliminar(numero);
            System.out.println("Curso eliminado exitosamente");
        } else {
            System.out.println("Error: Curso no encontrado");
        }
    }
}