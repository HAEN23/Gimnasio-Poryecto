package Menus;

import Repositorios.SuscriptorRepo;
import Repositorios.UsuarioRepository;
import modelos.Suscriptor;
import modelos.Usuario;
import java.util.ArrayList;
import java.util.Optional;
import java.util.Scanner;

public class MenuSuscriptoresNuevo {
    private SuscriptorRepo suscriptorRepo;
    private UsuarioRepository usuarioRepo;
    private Scanner scanner;

    public MenuSuscriptoresNuevo() {
        this.suscriptorRepo = new SuscriptorRepo();
        this.usuarioRepo = UsuarioRepository.getInstance();
        this.scanner = new Scanner(System.in);
    }

    public static void main(String[] args) {
        MenuSuscriptoresNuevo menu = new MenuSuscriptoresNuevo();
        menu.mostrarMenu();
    }

    public void mostrarMenu() {
        int opcion;
        do {
            System.out.println("\n=== MENÚ DE GESTIÓN DE SUSCRIPTORES ===");
            System.out.println("1. Crear nuevo suscriptor (desde usuario existente)");
            System.out.println("2. Buscar suscriptor por número de membresía");
            System.out.println("3. Filtrar suscriptores por nivel");
            System.out.println("4. Mostrar todos los suscriptores activos");
            System.out.println("5. Eliminar suscriptor");
            System.out.println("6. Salir");
            System.out.print("Seleccione una opción: ");

            opcion = scanner.nextInt();
            scanner.nextLine(); // Limpiar buffer

            switch (opcion) {
                case 1:
                    agregarSuscriptor();
                    break;
                case 2:
                    buscarPorMembresia();
                    break;
                case 3:
                    filtrarPorNivel();
                    break;
                case 4:
                    mostrarActivos();
                    break;
                case 5:
                    eliminarSuscriptor();
                    break;
                case 6:
                    System.out.println("Regresando al menú principal...");
                    break;
                default:
                    System.out.println("Opción no válida. Intente de nuevo.");
            }
        } while (opcion != 6);
    }

    private void agregarSuscriptor() {
        System.out.println("\n--- CREAR NUEVO SUSCRIPTOR ---");

        // Primero mostrar usuarios disponibles
        ArrayList<Usuario> usuarios = usuarioRepo.getAll();
        if (usuarios.isEmpty()) {
            System.out.println(" No hay usuarios registrados.");
            System.out.println(" Debe crear un usuario primero en el Menú de Usuarios.");
            return;
        }

        System.out.println(" Usuarios disponibles:");
        System.out.println("========================");
        for (Usuario u : usuarios) {
            System.out.println(
                    "ID: " + u.getId() + " - " + u.getNombre() + " " + u.getApellido() + " (" + u.getContacto() + ")");
        }
        System.out.println("========================");

        System.out.print("Ingrese el ID del usuario: ");
        int idUsuario = scanner.nextInt();
        scanner.nextLine();

        Optional<Usuario> usuarioOpt = usuarioRepo.findById(idUsuario);
        if (!usuarioOpt.isPresent()) {
            System.out.println(" Usuario no encontrado.");
            return;
        }

        Usuario usuario = usuarioOpt.get();

        System.out.print("Número de membresía (ej: MEM-2024-001): ");
        String numeroMembresia = scanner.nextLine();

        // Verificar que no exista ya ese número de membresía
        if (suscriptorRepo.existe(numeroMembresia)) {
            System.out.println(" Ya existe un suscriptor con ese número de membresía.");
            return;
        }

        System.out.print("Nivel (Básico/Premium/VIP): ");
        String nivel = scanner.nextLine();

        // Crear suscriptor
        Suscriptor suscriptor = new Suscriptor(usuario, numeroMembresia, nivel);
        suscriptorRepo.guardar(suscriptor);

        System.out.println("\n ¡Suscriptor creado exitosamente!");
        System.out.println("Usuario: " + usuario.getNombre() + " " + usuario.getApellido());
        System.out.println(" Membresía: " + numeroMembresia);
        System.out.println(" Nivel: " + nivel);
        System.out.println(" Usuario guardado en BD (ID: " + usuario.getId() + ")");
        System.out.println(" Suscriptor guardado en memoria");
    }

    private void buscarPorMembresia() {
        System.out.println("\n--- BUSCAR SUSCRIPTOR ---");
        System.out.print("Ingrese el número de membresía: ");
        String numeroMembresia = scanner.nextLine();

        Optional<Suscriptor> suscriptorOpt = suscriptorRepo.buscarPorMembresia(numeroMembresia);
        if (suscriptorOpt.isPresent()) {
            System.out.println("\n Suscriptor encontrado:");
            mostrarSuscriptor(suscriptorOpt.get());
        } else {
            System.out.println(" No se encontró ningún suscriptor con esa membresía.");
        }
    }

    private void filtrarPorNivel() {
        System.out.println("\n--- FILTRAR POR NIVEL ---");
        System.out.print("Ingrese el nivel (Básico/Premium/VIP): ");
        String nivel = scanner.nextLine();

        ArrayList<Suscriptor> filtrados = suscriptorRepo.filtrarPorNivel(nivel);
        if (filtrados.isEmpty()) {
            System.out.println(" No se encontraron suscriptores con ese nivel.");
        } else {
            System.out.println(" Suscriptores con nivel " + nivel + " (" + filtrados.size() + " encontrados):");
            System.out.println("=".repeat(50));
            for (Suscriptor s : filtrados) {
                mostrarSuscriptor(s);
                System.out.println("-".repeat(30));
            }
        }
    }

    private void mostrarActivos() {
        System.out.println("\n--- SUSCRIPTORES ACTIVOS ---");
        ArrayList<Suscriptor> activos = suscriptorRepo.obtenerActivos();

        if (activos.isEmpty()) {
            System.out.println(" No hay suscriptores activos.");
        } else {
            System.out.println(" Total de suscriptores activos: " + activos.size());
            System.out.println("=".repeat(50));
            for (Suscriptor s : activos) {
                mostrarSuscriptor(s);
                System.out.println("-".repeat(30));
            }
        }
    }

    private void eliminarSuscriptor() {
        System.out.println("\n--- ELIMINAR SUSCRIPTOR ---");
        System.out.print("Ingrese el número de membresía: ");
        String numeroMembresia = scanner.nextLine();

        if (suscriptorRepo.existe(numeroMembresia)) {
            // Mostrar información antes de eliminar
            Optional<Suscriptor> suscriptorOpt = suscriptorRepo.buscarPorMembresia(numeroMembresia);
            if (suscriptorOpt.isPresent()) {
                System.out.println("\nSuscriptor a eliminar:");
                mostrarSuscriptor(suscriptorOpt.get());

                System.out.print("\n¿Está seguro que desea eliminar este suscriptor? (s/n): ");
                String confirmacion = scanner.nextLine();

                if (confirmacion.equalsIgnoreCase("s")) {
                    suscriptorRepo.eliminar(numeroMembresia);
                    System.out.println(" Suscriptor eliminado exitosamente.");
                    System.out.println("ℹ  El usuario permanece en la base de datos.");
                } else {
                    System.out.println(" Eliminación cancelada.");
                }
            }
        } else {
            System.out.println(" No se encontró ningún suscriptor con esa membresía.");
        }
    }

    private void mostrarSuscriptor(Suscriptor suscriptor) {
        System.out.println(" Nombre: " + suscriptor.getNombre() + " " + suscriptor.getApellido());
        System.out.println(" Contacto: " + suscriptor.getContacto());
        System.out.println(" Membresía: " + suscriptor.getNumeroMembresia());
        System.out.println(" Nivel: " + suscriptor.getNivel());
        System.out.println(" Estado: " + (suscriptor.isActive() ? " Activo" : " Inactivo"));
        System.out.println(" ID Usuario en BD: " + suscriptor.getId());
    }
}
