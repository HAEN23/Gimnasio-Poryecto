package Menus;

import modelos.Asistencia;
import Repositorios.Asistenciarepo;
import Repositorios.AdministrarRepo;
import java.util.Scanner;
import java.util.Optional;

public class MenuAsistencias {
    private static Asistenciarepo repositorio = AdministrarRepo.getAsistenciaRepo();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            System.out.println("\n=== MENÚ DE ASISTENCIAS ===");
            System.out.println("1. Registrar nueva asistencia");
            System.out.println("2. Tomar asistencia");
            System.out.println("3. Eliminar registro de asistencia");
            System.out.println("4. Salir");
            System.out.print("Seleccione una opción: ");

            int opcion = scanner.nextInt();
            scanner.nextLine(); // Limpiar buffer

            switch (opcion) {
                case 1:
                    crearAsistencia();
                    break;
                case 2:
                    tomarAsistencia();
                    break;
                case 3:
                    eliminarAsistencia();
                    break;
                case 4:
                    System.out.println("Regresando al menú principal...");
                    return;
                default:
                    System.out.println("Opción no válida");
            }
        }
    }

    private static void crearAsistencia() {
        System.out.println("\n--- CREAR REGISTRO DE ASISTENCIA ---");
        System.out.print("ID del curso: ");
        String cursoId = scanner.nextLine();

        if (repositorio.existe(cursoId)) {
            System.out.println("Error: Ya existe un registro para este curso");
            return;
        }

        Asistencia nuevaAsistencia = new Asistencia(cursoId);
        repositorio.guardar(nuevaAsistencia);
        System.out.println("Registro de asistencia creado para el curso: " + cursoId);
    }

    private static void tomarAsistencia() {
        System.out.println("\n--- TOMAR ASISTENCIA ---");
        System.out.print("ID del curso: ");
        String cursoId = scanner.nextLine();

        Optional<Asistencia> asistenciaOpt = repositorio.buscar(cursoId);
        if (!asistenciaOpt.isPresent()) {
            System.out.println("Error: No existe registro para este curso");
            return;
        }

        Asistencia asistencia = asistenciaOpt.get();

        System.out.print("Número de membresía del alumno (ej. MEM-001): ");
        String membresia = scanner.nextLine();
        System.out.print("¿Asistió? (S/N): ");
        boolean presente = scanner.nextLine().equalsIgnoreCase("S");

        asistencia.registrar(membresia, presente);
        System.out.println("Asistencia registrada correctamente");
    }

    private static void eliminarAsistencia() {
        System.out.println("\n--- ELIMINAR REGISTRO ---");
        System.out.print("ID del curso: ");
        String cursoId = scanner.nextLine();

        if (!repositorio.existe(cursoId)) {
            System.out.println("Error: No existe registro para este curso");
            return;
        }

        repositorio.eliminar(cursoId);
        System.out.println("Registro de asistencia eliminado");
    }
}