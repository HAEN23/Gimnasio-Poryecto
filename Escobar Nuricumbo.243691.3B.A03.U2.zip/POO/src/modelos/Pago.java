package modelos;

import java.time.LocalDate;

public class Pago {
    private final String idPago;
    private final double monto;
    private final LocalDate fecha;
    private final String numeroMembresia; // ID del suscriptor
    private boolean completado;

    public Pago(double monto, String numeroMembresia) {
        this.idPago = generarIdPago();
        this.monto = monto;
        this.fecha = LocalDate.now();
        this.numeroMembresia = numeroMembresia;
        this.completado = false;
    }

    private String generarIdPago() {
        return "PAG-" + LocalDate.now().getYear() + //prefijo
                String.format("%06d", (int) (Math.random() * 10));//Especificador de formato que se utiliza para formatear números enteros, asegurando que tengan al menos 2
    }

    // Método para procesar el pago de membresía
    public boolean procesarPagoMembresia() {
        this.completado = (this.monto > 0);
        return this.completado;
    }

    // Getters
    public String getIdPago() {
        return idPago;
    }

    public double getMonto() {
        return monto;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public String getNumeroMembresia() {
        return numeroMembresia;
    }

    public boolean isCompletado() {
        return completado;
    }

    @Override
    public String toString() {
        return String.format(
                "Pago Membresía [ID: %s, Monto: $%.2f, Fecha: %s, Membresía: %s, Estado: %s]",
                idPago, monto, fecha, numeroMembresia, completado ? "COMPLETADO" : "PENDIENTE");
    }
}