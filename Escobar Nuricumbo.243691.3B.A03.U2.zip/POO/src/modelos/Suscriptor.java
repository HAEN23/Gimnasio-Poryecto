package modelos;

public class Suscriptor extends Usuario {
    private String numeroMembresia;
    private boolean active;
    private String nivel;

    // Constructor 
    public Suscriptor(String nombre, String apellido, String contacto, String numeroMembresia, boolean active, String nivel) {
        super(nombre, apellido, contacto);
        this.numeroMembresia = numeroMembresia;
        this.active = active;
        this.nivel = nivel;
    }

    // Constructor que convierte Usuario a Suscriptor
    public Suscriptor(Usuario usuario, String numeroMembresia, String nivel) {
        super(usuario.getNombre(), usuario.getApellido(), usuario.getContacto());
        this.numeroMembresia = numeroMembresia;
        this.active = true;  // Por defecto esta activo
        this.nivel = nivel;
    }

    // Método para convertir Usuario a Suscriptor
    public static Suscriptor convertir(Usuario usuario, String numeroMembresia, String nivel) {
        return new Suscriptor(usuario, numeroMembresia, nivel);
    }

    // Getters 
    public String getNumeroMembresia()  { 
        return numeroMembresia; 
    }
    public boolean isActive() { 
        return active; 
    }
    public String getNivel() { 
        return nivel;
     }
    
    // Setters 
    public void setActive(boolean active) { this.active = active; }
    public void setNivel(String nivel) { this.nivel = nivel; }
}
