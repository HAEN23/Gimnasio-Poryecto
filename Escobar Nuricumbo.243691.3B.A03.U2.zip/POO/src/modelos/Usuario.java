package modelos;

import java.util.ArrayList;

public class Usuario {
    private int id;
    private String nombre;
    private String apellido;
    private String contacto;

    // Constructor para nuevos usuarios (sin ID, se asignará desde BD)
    public Usuario(String nombre, String apellido, String contacto) {
        this.id = 0; // ID = 0 indica que es un nuevo usuario
        this.nombre = nombre;
        this.apellido = apellido;
        this.contacto = contacto;
    }

    // Constructor para usuarios existentes (con ID desde BD)
    public Usuario(int id, String nombre, String apellido, String contacto) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.contacto = contacto;
    }

    // Getters
    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public String getContacto() {
        return contacto;
    }

    // Setters
    public void setId(int id) {
        this.id = id;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public void setContacto(String contacto) {
        this.contacto = contacto;
    }

    @Override
    public String toString() {
        return "Usuario{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                ", apellido='" + apellido + '\'' +
                ", contacto='" + contacto + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null || getClass() != obj.getClass())
            return false;
        Usuario other = (Usuario) obj;
        return id == other.id;
    }

    @Override
    public int hashCode() {
        return Integer.hashCode(id);
    }

    public static boolean existeUsuario(ArrayList<Usuario> usuarios, int id) {
        return usuarios.stream().anyMatch(u -> u.getId() == id);
    }

}
