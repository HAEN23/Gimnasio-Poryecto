package modelos;

public class Instructor extends Usuario {
    private String numeroInstructor;  // Ejemplo: "INST-001"

    // Constructor
    public Instructor(String nombre, String apellido, String contacto, String numeroInstructor) {
        super(nombre, apellido, contacto);  // Llama al constructor de Usuario
        this.numeroInstructor = numeroInstructor;
    }

    // Getter y Setter específico
    public String getNumeroInstructor() {
        return numeroInstructor;
    }

    public void setNumeroInstructor(String numeroInstructor) {
        this.numeroInstructor = numeroInstructor;
    }

    // Sobrescribe toString() para incluir el número de instructor
    @Override
    public String toString() {
        return "Instructor{" +
                "id=" + getId() +
                ", nombre='" + getNombre() + '\'' +
                ", apellido='" + getApellido() + '\'' +
                ", contacto='" + getContacto() + '\'' +
                ", numeroInstructor='" + numeroInstructor + '\'' +
                '}';
    }
}

 

