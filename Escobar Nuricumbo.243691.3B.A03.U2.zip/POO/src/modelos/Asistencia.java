package modelos;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

public class Asistencia {
    private final String cursoId;
    private final Map<String, Registro> registros = new HashMap<>();//Se usa para alamcenar las asistencias y el HasPam sirve para un acceso rapido a los registros

    public Asistencia(String cursoId) {
        this.cursoId = cursoId;
    }

    public static class Registro {
        public final LocalDateTime fecha = LocalDateTime.now();
        public boolean presente;

        public Registro(boolean presente) {
            this.presente = presente;
        }
    }

    public void registrar(String membresia, boolean presente) {
        registros.put(membresia, new Registro(presente));// para registrar la asistencia(para actualizar Registro)
    }

    public String getCursoId() {
        return cursoId;
    }
}