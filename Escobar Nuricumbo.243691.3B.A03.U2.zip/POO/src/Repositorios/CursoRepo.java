package Repositorios;

import Cursos.Curso;
import java.util.ArrayList;
import java.util.Optional;

public class CursoRepo {
    private ArrayList<Curso> cursos;

    // Constructor
    public CursoRepo() {
        this.cursos = new ArrayList<>();
    }

    // Guardar un curso
    public void guardar(Curso curso) {
        if (curso != null) {
            cursos.add(curso);
        }
    }

    // Buscar curso por número
    public Optional<Curso> buscar(int numero) {
        for (Curso curso : cursos) {
            if (curso.getNumero() == numero) {
                return Optional.of(curso);
            }
        }
        return Optional.empty();
    }

    // Eliminar curso por número
    public void eliminar(int numero) {
        cursos.removeIf(c -> c.getNumero() == numero);
    }

    // Verificar si existe un curso
    public boolean existe(int numero) {
        for (Curso curso : cursos) {
            if (curso.getNumero() == numero) {
                return true;
            }
        }
        return false;
    }

    // Obtener todos los cursos
    public ArrayList<Curso> obtenerTodos() {
        return new ArrayList<>(cursos);
    }
}