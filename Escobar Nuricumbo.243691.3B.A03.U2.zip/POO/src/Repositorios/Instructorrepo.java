package Repositorios;

import modelos.Instructor;
import java.util.ArrayList;
import java.util.Optional;

public class Instructorrepo {
    private ArrayList<Instructor> instructores;

    // Constructor
    public Instructorrepo() {
        this.instructores = new ArrayList<>();
    }

    // Guardar un instructor
    public void guardar(Instructor instructor) {
        if (instructor != null) {
            instructores.add(instructor);
        }
    }

    // Buscar instructor por número
    public Optional<Instructor> buscarPorNumero(String numeroInstructor) {
        for (Instructor instructor : instructores) {
            if (instructor.getNumeroInstructor().equals(numeroInstructor)) {
                return Optional.of(instructor);
            }
        }
        return Optional.empty();
    }

    // Obtener todos los instructores
    public ArrayList<Instructor> obtenerTodos() {
        return new ArrayList<>(instructores);
    }

    // Eliminar instructor por número
    public void eliminar(String numeroInstructor) {
        instructores.removeIf(i -> i.getNumeroInstructor().equals(numeroInstructor));
    }

    // Verificar si existe un instructor
    public boolean existe(String numeroInstructor) {
        for (Instructor instructor : instructores) {
            if (instructor.getNumeroInstructor().equals(numeroInstructor)) {
                return true;
            }
        }
        return false;
    }
}