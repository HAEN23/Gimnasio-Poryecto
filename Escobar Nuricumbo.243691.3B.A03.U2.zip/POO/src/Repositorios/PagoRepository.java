package Repositorios;

import modelos.Pago;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class PagoRepository {
    private final List<Pago> pagos = new ArrayList<>();

    // Guardar un pago
    public void guardar(Pago pago) {
        if (pago != null) {
            pagos.add(pago);
        }
    }

    // Buscar pago por ID
    public Optional<Pago> buscarPorId(String idPago) {
        return pagos.stream()
                .filter(p -> p.getIdPago().equals(idPago)) //p representa un objeto de la clase Pago. La expresión lambda se utiliza para operar sobre una colección de objetos Pago, como en un flujo (stream).
                .findFirst();
    }

    // Buscar pagos por número de membresía
    public List<Pago> buscarPorMembresia(String numeroMembresia) {
        return pagos.stream()
                .filter(p -> p.getNumeroMembresia().equals(numeroMembresia))
                .toList();
    }

    // Obtener todos los pagos
    public List<Pago> obtenerTodos() {
        return new ArrayList<>(pagos);
    }
}