package Repositorios;

import modelos.Usuario;
import modelos.Suscriptor;
import util.DatabaseConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.Optional;

/**
 * Repositorio para usuarios con soporte para MariaDB
 * Implementa patrón Singleton y hereda funcionalidad base
 */
public class UsuarioRepository {
    private static UsuarioRepository instance;
    private ArrayList<Usuario> items; // Cache en memoria
    private static final String TABLA = "usuarios";
    private static final String BD = "gym";

    private UsuarioRepository() {
        this.items = new ArrayList<>();
        cargarDesdeBD(); // Cargar datos desde BD al inicializar
    }

    public static UsuarioRepository getInstance() {
        if (instance == null) {
            instance = new UsuarioRepository();
        }
        return instance;
    }

    /**
     * Cargar todos los usuarios desde la base de datos al cache
     */
    private void cargarDesdeBD() {
        try {
            String sql = "SELECT * FROM " + BD + "." + TABLA;

            try (Connection conn = DatabaseConnection.getConnection();
                    Statement stmt = conn.createStatement();
                    ResultSet rs = stmt.executeQuery(sql)) {

                items.clear(); // Limpiar cache
                while (rs.next()) {
                    Usuario usuario = new Usuario(
                            rs.getInt("id"),
                            rs.getString("nombre"),
                            rs.getString("apellido"),
                            rs.getString("contacto"));
                    items.add(usuario);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al cargar usuarios desde BD: " + e.getMessage());
        }
    }

    /**
     * Guardar usuario en base de datos y actualizar cache
     */
    public void save(Usuario usuario) {
        try {
            if (usuario.getId() == 0) { // Nuevo usuario
                String sql = "INSERT INTO " + BD + "." + TABLA + " (nombre, apellido, contacto) VALUES (?, ?, ?)";

                try (Connection conn = DatabaseConnection.getConnection();
                        PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

                    stmt.setString(1, usuario.getNombre());
                    stmt.setString(2, usuario.getApellido());
                    stmt.setString(3, usuario.getContacto());

                    int rowsAffected = stmt.executeUpdate();
                    if (rowsAffected > 0) {
                        // Obtener ID generado
                        try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                            if (generatedKeys.next()) {
                                usuario.setId(generatedKeys.getInt(1));
                            }
                        }
                        items.add(usuario); // Agregar al cache
                    }
                }
            } else { // Actualizar usuario existente
                updateUser(usuario);
            }
        } catch (SQLException e) {
            System.err.println("Error al guardar usuario: " + e.getMessage());
            // Fallback: guardar solo en memoria
            if (!items.contains(usuario)) {
                items.add(usuario);
            }
        }
    }

    /**
     * Actualizar usuario en base de datos
     */
    private void updateUser(Usuario usuario) throws SQLException {
        String sql = "UPDATE " + BD + "." + TABLA + " SET nombre=?, apellido=?, contacto=? WHERE id=?";

        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, usuario.getNombre());
            stmt.setString(2, usuario.getApellido());
            stmt.setString(3, usuario.getContacto());
            stmt.setInt(4, usuario.getId());

            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                // Actualizar en cache
                replaceUser(usuario.getId(), usuario);
            }
        }
    }

    /**
     * Buscar usuario por ID
     */
    public Optional<Usuario> findById(int id) {
        // Primero buscar en cache
        Optional<Usuario> cached = items.stream()
                .filter(usuario -> usuario.getId() == id)
                .findFirst();

        if (cached.isPresent()) {
            return cached;
        }

        // Si no está en cache, buscar en BD
        try {
            String sql = "SELECT * FROM " + BD + "." + TABLA + " WHERE id = ?";

            try (Connection conn = DatabaseConnection.getConnection();
                    PreparedStatement stmt = conn.prepareStatement(sql)) {

                stmt.setInt(1, id);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        Usuario usuario = new Usuario(
                                rs.getString("nombre"),
                                rs.getString("apellido"),
                                rs.getString("contacto"));
                        usuario.setId(rs.getInt("id"));
                        items.add(usuario); // Agregar al cache
                        return Optional.of(usuario);
                    }
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al buscar usuario: " + e.getMessage());
        }

        return Optional.empty();
    }

    /**
     * Verificar si existe usuario por ID
     */
    public boolean existsById(int id) {
        return findById(id).isPresent();
    }

    /**
     * Obtener todos los suscriptores
     */
    public ArrayList<Suscriptor> getAllSubscriptors() {
        ArrayList<Suscriptor> suscriptores = new ArrayList<>();
        for (Usuario u : items) {
            if (u instanceof Suscriptor) {
                suscriptores.add((Suscriptor) u);
            }
        }
        return suscriptores;
    }

    /**
     * Obtener usuarios que no son suscriptores
     */
    public ArrayList<Usuario> getNonSubscriptors() {
        ArrayList<Usuario> usuarios = new ArrayList<>();
        for (Usuario u : items) {
            if (!(u instanceof Suscriptor)) {
                usuarios.add(u);
            }
        }
        return usuarios;
    }

    /**
     * Eliminar usuario por ID
     */
    public boolean removeById(int id) {
        try {
            String sql = "DELETE FROM " + BD + "." + TABLA + " WHERE id = ?";

            try (Connection conn = DatabaseConnection.getConnection();
                    PreparedStatement stmt = conn.prepareStatement(sql)) {

                stmt.setInt(1, id);
                int rowsAffected = stmt.executeUpdate();

                if (rowsAffected > 0) {
                    // Remover del cache
                    return items.removeIf(usuario -> usuario.getId() == id);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al eliminar usuario: " + e.getMessage());
            // Fallback: eliminar solo del cache
            return items.removeIf(usuario -> usuario.getId() == id);
        }
        return false;
    }

    /**
     * Reemplazar usuario en el cache
     */
    public boolean replaceUser(int id, Usuario newUser) {
        for (int i = 0; i < items.size(); i++) {
            if (items.get(i).getId() == id) {
                items.set(i, newUser);
                return true;
            }
        }
        return false;
    }

    /**
     * Obtener todos los usuarios
     */
    public ArrayList<Usuario> getAll() {
        cargarDesdeBD(); // Refrescar cache
        return new ArrayList<>(items);
    }

    /**
     * Buscar usuarios por nombre
     */
    public ArrayList<Usuario> findByNombre(String nombre) {
        ArrayList<Usuario> encontrados = new ArrayList<>();
        for (Usuario usuario : items) {
            if (usuario.getNombre().toLowerCase().contains(nombre.toLowerCase())) {
                encontrados.add(usuario);
            }
        }
        return encontrados;
    }

    /**
     * Sincronizar cache con base de datos
     */
    public void syncWithDatabase() {
        cargarDesdeBD();
    }

    /**
     * Obtener el siguiente ID disponible
     */
    public int getNextId() {
        try {
            String sql = "SELECT MAX(id) + 1 as next_id FROM " + BD + "." + TABLA;

            try (Connection conn = DatabaseConnection.getConnection();
                    Statement stmt = conn.createStatement();
                    ResultSet rs = stmt.executeQuery(sql)) {

                if (rs.next()) {
                    int nextId = rs.getInt("next_id");
                    return nextId > 0 ? nextId : 1;
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener siguiente ID: " + e.getMessage());
        }

        // Fallback: buscar en cache
        int maxId = items.stream().mapToInt(Usuario::getId).max().orElse(0);
        return maxId + 1;
    }
}
