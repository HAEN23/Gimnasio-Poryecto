package Repositorios;

public class AdministrarRepo {
    // Repositorios estáticos compartidos entre todos los menus
    private static final SuscriptorRepo suscriptorRepo = new SuscriptorRepo();
    private static final UsuarioRepository usuarioRepo = UsuarioRepository.getInstance();
    private static final Instructorrepo instructorRepo = new Instructorrepo();
    private static final CursoRepo cursoRepo = new CursoRepo();
    private static final PagoRepository pagoRepo = new PagoRepository();
    private static final Asistenciarepo asistenciaRepo = new Asistenciarepo();

    // Métodos para obtener los repositorios
    public static SuscriptorRepo getSuscriptorRepo() {
        return suscriptorRepo;
    }

    public static UsuarioRepository getUsuarioRepository() {
        return usuarioRepo;
    }

    public static Instructorrepo getInstructorRepo() {
        return instructorRepo;
    }

    public static CursoRepo getCursoRepo() {
        return cursoRepo;
    }

    public static PagoRepository getPagoRepo() {
        return pagoRepo;
    }

    public static Asistenciarepo getAsistenciaRepo() {
        return asistenciaRepo;
    }
}
