package Repositorios;

import modelos.Asistencia;
import java.util.ArrayList;
import java.util.Optional;

public class Asistenciarepo {
    private ArrayList<Asistencia> asistencias;

    public Asistenciarepo() {
        this.asistencias = new ArrayList<>();
    }

    // Guardar una asistencia
    public void guardar(Asistencia asistencia) {
        if (asistencia != null) {
            // Si ya existe
            if (existe(asistencia.getCursoId())) {
                System.out.println("Ya existe asistencia para el curso: " + asistencia.getCursoId());
                return;
            }
            asistencias.add(asistencia);
        }
    }

    // Buscar asistencia por ID de curso
    public Optional<Asistencia> buscar(String cursoId) {
        return asistencias.stream()
                .filter(a -> a.getCursoId().equals(cursoId))
                .findFirst();
    }

    // Eliminar asistencia por ID de curso
    public void eliminar(String cursoId) {
        asistencias.removeIf(a -> a.getCursoId().equals(cursoId));
    }

    // Verificar si existe asistencia para un curso
    public boolean existe(String cursoId) {
        return asistencias.stream()
                .anyMatch(a -> a.getCursoId().equals(cursoId));
    }
}
