package Repositorios;

import modelos.Suscriptor;
import java.util.ArrayList;
import java.util.Optional;

public class SuscriptorRepo {
    private ArrayList<Suscriptor> suscriptores;

    // Constructor
    public SuscriptorRepo() {
        this.suscriptores = new ArrayList<>();
    }

    // Guardar un suscriptor
    public void guardar(Suscriptor suscriptor) {
        if (suscriptor != null) {
            suscriptores.add(suscriptor);
        }
    }

    // Buscar suscriptor por número de membresía
    public Optional<Suscriptor> buscarPorMembresia(String numeroMembresia) {
        for (Suscriptor suscriptor : suscriptores) {
            if (suscriptor.getNumeroMembresia().equals(numeroMembresia)) {
                return Optional.of(suscriptor);
            }
        }
        return Optional.empty();
    }

    // Filtrar suscriptores por nivel
    public ArrayList<Suscriptor> filtrarPorNivel(String nivel) {
        ArrayList<Suscriptor> filtrados = new ArrayList<>();
        for (Suscriptor suscriptor : suscriptores) {
            if (suscriptor.getNivel().equals(nivel)) {
                filtrados.add(suscriptor);
            }
        }
        return filtrados;
    }

    // Obtener solo suscriptores activos
    public ArrayList<Suscriptor> obtenerActivos() {
        ArrayList<Suscriptor> activos = new ArrayList<>();
        for (Suscriptor suscriptor : suscriptores) {
            if (suscriptor.isActive()) {
                activos.add(suscriptor);
            }
        }
        return activos;
    }

    // Eliminar suscriptor por número de membresía
    public void eliminar(String numeroMembresia) {
        suscriptores.removeIf(s -> s.getNumeroMembresia().equals(numeroMembresia));
    }

    // Verificar si existe un suscriptor
    public boolean existe(String numeroMembresia) {
        for (Suscriptor suscriptor : suscriptores) {
            if (suscriptor.getNumeroMembresia().equals(numeroMembresia)) {
                return true;
            }
        }
        return false;
    }
}