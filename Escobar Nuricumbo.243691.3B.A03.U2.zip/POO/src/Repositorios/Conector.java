package Repositorios;

import modelos.Usuario;
import util.DatabaseConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Repositorio para usuarios que guarda en la base de datos
 */
public class Conector {
    private static final String TABLA = "usuarios";
    private static final String BD = "gym";

    /**
     * Guarda un usuario en la base de datos y asigna el ID generado
     */
    public void guardar(Usuario usuario) throws SQLException {
        String sql = "INSERT INTO " + BD + "." + TABLA + " (nombre, apellido, contacto) VALUES (?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setString(1, usuario.getNombre());
            stmt.setString(2, usuario.getApellido());
            stmt.setString(3, usuario.getContacto());

            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                // Obtener el ID generado y asignarlo al usuario
                try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        usuario.setId(generatedKeys.getInt(1));
                    }
                }
            }
        }
    }

    /**
     * Busca un usuario por ID
     */
    public Optional<Usuario> buscarPorId(int id) throws SQLException {
        String sql = "SELECT * FROM " + BD + "." + TABLA + " WHERE id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Usuario usuario = new Usuario(
                            rs.getString("nombre"),
                            rs.getString("apellido"),
                            rs.getString("contacto"));
                    usuario.setId(rs.getInt("id"));
                    return Optional.of(usuario);
                }
            }
        }
        return Optional.empty();
    }

    /**
     * Busca un usuario por nombre y apellido
     */
    public Optional<Usuario> buscarPorNombre(String nombre, String apellido) throws SQLException {
        String sql = "SELECT * FROM " + BD + "." + TABLA + " WHERE nombre = ? AND apellido = ?";

        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, nombre);
            stmt.setString(2, apellido);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Usuario usuario = new Usuario(
                            rs.getString("nombre"),
                            rs.getString("apellido"),
                            rs.getString("contacto"));
                    usuario.setId(rs.getInt("id"));
                    return Optional.of(usuario);
                }
            }
        }
        return Optional.empty();
    }

    /**
     * Obtiene todos los usuarios
     */
    public List<Usuario> obtenerTodos() throws SQLException {
        List<Usuario> usuarios = new ArrayList<>();
        String sql = "SELECT * FROM " + BD + "." + TABLA;

        try (Connection conn = DatabaseConnection.getConnection();
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Usuario usuario = new Usuario(
                        rs.getString("nombre"),
                        rs.getString("apellido"),
                        rs.getString("contacto"));
                usuario.setId(rs.getInt("id"));
                usuarios.add(usuario);
            }
        }
        return usuarios;
    }

    /**
     * Verifica si existe un usuario con el ID dado
     */
    public boolean existe(int id) throws SQLException {
        String sql = "SELECT COUNT(*) FROM " + BD + "." + TABLA + " WHERE id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        }
        return false;
    }

    /**
     * Elimina un usuario por ID
     */
    public boolean eliminar(int id) throws SQLException {
        String sql = "DELETE FROM " + BD + "." + TABLA + " WHERE id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        }
    }
}
