package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
    
    private static final String URL = "jdbc:mariadb://localhost:3306/gym";
    private static final String USER = "root";
    private static final String PASSWORD = "";

    /**
     * Obtiene una conexión a la base de datos MariaDB
     * 
     * @return Connection objeto de conexión
     * @throws SQLException si hay error en la conexión
     */
    public static Connection getConnection() throws SQLException {
        try {
            System.out.println("Conectando a la base de datos...");
            Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println(" Conexión exitosa!");
            return conn;
        } catch (SQLException e) {
            System.err.println("✗Error al conectar a la base de datos:");
            System.err.println("URL: " + URL);
            System.err.println("Usuario: " + USER);
            throw e;//Excepcion que ha sido capturada y se vuelve a lanzar para que el llamador pueda manejarla
        }
    }

    /**
     * Método para probar la conexión
     */
   
     public static void testConnection() {
        try (Connection conn = getConnection()) {
            System.out.println(" Conexión exitosa!");
        } catch (SQLException e) {
            System.err.println(" Conexión falló:");
            e.printStackTrace();
        }
    }
}
