package Cursos;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import modelos.Instructor;
import modelos.Suscriptor;

public class Curso {
    private final int numero; // Número del curso
    private String periodo; // Periodo del curso
    private String informacion; // Información general
    private final ArrayList<Suscriptor> suscriptores; // Lista de suscriptores
    private final Instructor instructor; // Instructor asignado
    private Map<String, Boolean> asistencia; // Control de asistencia

    // Constructor principal (con instructor)
    public Curso(int numero, String periodo, String informacion, Instructor instructor) {
        this.numero = numero;
        this.periodo = periodo;
        this.informacion = informacion;
        this.instructor = instructor;
        this.suscriptores = new ArrayList<>();
        this.asistencia = new HashMap<>();
    }

    // Constructor alternativo
    public Curso(int numero, String periodo, String informacion) {
        this(numero, periodo, informacion, null);
    }

    // Método para inscribir suscriptores
    public boolean inscribir(Suscriptor suscriptor) {
        if (!suscriptores.contains(suscriptor)) {
            suscriptores.add(suscriptor);
            return true;
        }
        return false;
    }

    // Registro de asistencia
    public void registrarAsistencia(String numeroMembresia, boolean presente) {
        if (existeSuscriptor(numeroMembresia)) {
            asistencia.put(numeroMembresia, presente);
        } else {
            System.out.println("Error: Suscriptor no inscrito");
        }
    }

    // Método auxiliar para verificar suscriptores
    private boolean existeSuscriptor(String numeroMembresia) {
        return suscriptores.stream()
                .anyMatch(s -> s.getNumeroMembresia().equals(numeroMembresia));
    }

    // Getters
    public int getNumero() {
        return numero;
    }

    public String getPeriodo() {
        return periodo;
    }

    public String getInformacion() {
        return informacion;
    }

    public ArrayList<Suscriptor> getSuscriptores() {
        return suscriptores;
    }

    public String getInfoInstructor() {
        return instructor != null ? instructor.toString() : "Sin instructor asignado";
    }

    // Setters
    public void setPeriodo(String periodo) {
        this.periodo = periodo;
    }

    public void setInformacion(String informacion) {
        this.informacion = informacion;
    }

    @Override
    public String toString() {
        return String.format("Curso %d [Periodo: %s, Información: %s]",
                numero, periodo, informacion);
    }
}
