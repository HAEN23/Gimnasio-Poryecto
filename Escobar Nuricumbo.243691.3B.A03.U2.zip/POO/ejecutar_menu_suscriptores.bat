@echo off
echo Ejecutando Menu de Suscriptores...
java -cp "lib\mariadb-java-client-3.3.2.jar;bin" Menus.MenuSuscriptoresNuevo
pause
